package Ex7;

+public class Animals {
    public static void main(String... args){
        var cat = new Cat("Taylor");
        var dog = new Dog("Ruben");
        var fox = new Fox("Saitama");

        cat.printName();
        cat.sound();
        dog.printName();
        dog.sound();
        fox.printName();
        fox.sound();
    }
}