package Practice1.Ex6;

public interface Animal {
    void sound();
}