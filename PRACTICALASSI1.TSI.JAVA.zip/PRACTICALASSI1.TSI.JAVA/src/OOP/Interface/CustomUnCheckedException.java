package OOP.Interface;

public class CustomUnCheckedException extends {

}