package OOP.Interface;


public interface Payable {
    double getPrice();
}