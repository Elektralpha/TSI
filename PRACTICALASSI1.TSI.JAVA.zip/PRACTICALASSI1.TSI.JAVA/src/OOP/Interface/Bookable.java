package OOP.Interface;
public interface Bookable {
    String getName();
}
