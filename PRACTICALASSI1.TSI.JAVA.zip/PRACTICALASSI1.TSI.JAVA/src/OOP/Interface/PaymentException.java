package OOP.Interface;


public class PaymentException extends RuntimeException{

}