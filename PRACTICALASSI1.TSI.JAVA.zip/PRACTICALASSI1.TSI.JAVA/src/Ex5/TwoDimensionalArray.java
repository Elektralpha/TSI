package Ex5;public class TwoDimensionalArray {
}
